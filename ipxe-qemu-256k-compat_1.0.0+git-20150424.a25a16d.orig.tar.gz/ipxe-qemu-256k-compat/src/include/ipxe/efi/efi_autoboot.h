#ifndef _IPXE_EFI_AUTOBOOT_H
#define _IPXE_EFI_AUTOBOOT_H

/** @file
 *
 * EFI autoboot device
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern void efi_set_autoboot ( void );

#endif /* _IPXE_EFI_AUTOBOOT_H */
