#ifndef _PC_KBD_H
#define _PC_KBD_H

int kbd_ischar(void);

int kbd_getc(void);
#endif
