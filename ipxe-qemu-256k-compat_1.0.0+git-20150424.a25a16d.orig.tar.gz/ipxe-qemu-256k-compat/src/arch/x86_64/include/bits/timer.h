#ifndef _BITS_TIMER_H
#define _BITS_TIMER_H

/** @file
 *
 * x86_64-specific timer API implementations
 *
 */

#endif /* _BITS_TIMER_H */
